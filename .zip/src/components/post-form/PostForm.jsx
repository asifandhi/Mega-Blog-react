import React ,{useCallback} from 'react'
import { useForm } from 'react-hook-form';
import { Input,Button,RTE,Select } from '../index';
import appwriteService from '../../appwrite/config'
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';


export default function PostForm({ post }) {
    const {register , handleSubmit , watch , setValue ,control,getValues   } = useForm({
        defaultValues:{
            title: post?.title || "",
            slug: post?.$id || "",
            content: post?.content || "",
            status: post?.status || "active",
        }
    }); 

    const navigate = useNavigate();
    const userData = useSelector((state) => state.auth.userData);


    const submit = async(data) => {
        if(post){
            const file = data.image[0] ? await appwriteService.uploadFile(data.image[0]) : null;

            if(file){
                appwriteService.deleteFile(post.featuresimage);

            }

            const dbpost = await appwriteService.updatePost(post.$id,{
                ...data,
                featuresimage : file ? file.$id :undefined,
            })

            if(dbpost){
                navigate(`/post/${dbpost.$id}`);
            }
        }

        else{
            const file = data.image[0] ? await appwriteService.uploadFile(data.image[0]) : null;

             
            console.log("File :: ",file);
            const fileId = file ? file.$id : undefined;
            data.featuresimage = fileId;
            const dbpost = await appwriteService.createPost({
                ...data,
                userid : userData.$id
            });

            if(dbpost){
                navigate(`/post/${dbpost.$id}`);
            }
            
        }
    }

    const slugTransform = useCallback((value) => {
        if (value && typeof value === "string")
            return value
                .trim()
                .toLowerCase()
                .replace(/[^a-zA-Z\d\s]+/g, "-")
                .replace(/\s/g, "-");

        return "";
    }, []);

    React.useEffect(() => {
        const subscription = watch((value, { name }) => {
            if (name === "title") {
                setValue("slug", slugTransform(value.title), { shouldValidate: true });
            }
        });

        return () => subscription.unsubscribe();
    }, [watch, slugTransform, setValue]);



    


 
  return (
    <form onSubmit={handleSubmit(submit)} className="flex flex-wrap gap-4 bg-white rounded-2xl p-6 shadow-xl border border-purple-100">
        <div className="w-2/3 px-2">
            <Input
                label="Title :"
                placeholder="Title"
                className="mb-4"
                {...register("title", { required: true })}
            />
            <Input
                label="Slug :"
                placeholder="Slug"
                className="mb-4"
                {...register("slug", { required: true })}
                onInput={(e) => {
                    setValue("slug", slugTransform(e.currentTarget.value), { shouldValidate: true });
                }}
            />
            <RTE label="Content :" name="content" control={control} defaultValue={getValues("content")} />
        </div>
        <div className="w-1/3 px-2 flex flex-col gap-4">
            <Input
                label="Featured Image :"
                type="file"
                className="mb-4"
                accept="image/png, image/jpg, image/jpeg, image/gif"
                {...register("image", { required: !post })}
            />
            {post && (
                <div className="w-full mb-4">
                    <img
                        src={appwriteService.getFilePreview(post.featuresimage)}
                        alt={post.title}
                        className="rounded-xl w-full object-cover shadow-md"
                    />
                </div>
            )}
            <Select
                options={["active", "inactive"]}
                label="Status"
                className="mb-4"
                {...register("status", { required: true })}
            />
            <Button
                type="submit"
                bgColor={post ? "bg-gradient-to-r from-green-400 to-emerald-500" : "bg-gradient-to-r from-pink-500 to-purple-600"}
                className="w-full py-3 text-base"
            >
                {post ? "Update" : "Submit"}
            </Button>
        </div>
    </form>
)
}

 